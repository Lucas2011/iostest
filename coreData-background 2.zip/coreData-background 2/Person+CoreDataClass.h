//
//  Person+CoreDataClass.h
//  coreData
//
//  Created by Lucas on 12/28/23.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class NSMutableDictionary;

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Person+CoreDataProperties.h"
