//
//  Person+CoreDataProperties.h
//  coreData
//
//  Created by Lucas on 12/28/23.
//
//

#import "Person+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Person (CoreDataProperties)

+ (NSFetchRequest<Person *> *)fetchRequest NS_SWIFT_NAME(fetchRequest());

@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *age;
@property (nullable, nonatomic, retain) NSMutableDictionary *infos;
@property (nullable, nonatomic, retain) NSMutableArray *cars;

@end

NS_ASSUME_NONNULL_END
