#import "ViewController.h"
#import "AppDelegate.h" // Import the app delegate to access the managed object context
#import "Person+CoreDataProperties.h"
#import "DataManager.h"

@interface ViewController ()

@property (nonatomic,strong) UILabel * txtLabel;
@property (nonatomic,strong) UIButton * button;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
    [self performSelectorInBackground:@selector(update) withObject:nil];
    [self performSelectorInBackground:@selector(create) withObject:nil];
    [self performSelectorInBackground:@selector(get) withObject:nil];
}

- (void)setupUI {
    
    
    self.txtLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 80, 90)];
    [self.view addSubview:self.txtLabel];
    
    self.txtLabel.center = self.view.center;
    
    
    self.button = [[UIButton alloc] initWithFrame:CGRectMake(100, 200, 80, 90)];
    [self.button setTitle:@"++" forState:UIControlStateNormal];
    [self.button addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.button];

}

- (void)click {
    
    NSLog(@"click");

}
- (void)create {
    

    
    for (int i = 0; i < 1000 ; i ++) {
        NSLog(@"Create a new person");
        Person * person = [[DataManager sharedInstance] getANewDataInBackground];;
        person.name = [NSString stringWithFormat:@"%d",i];
        person.age = [NSString stringWithFormat:@"%d",i];
        [[DataManager sharedInstance] performCoreDataOperation];
        [NSThread sleepForTimeInterval:2];
        NSLog(@"Done Create a new person\n");
    }
  
}


- (void)get {
    
    while (true) {
        NSArray * array = [[DataManager sharedInstance] fetchDataInBackgroundAndNotifyMainThread];
        
        for (Person * person in array) {
            NSLog(@"name: %@ %@",person.name,person.age);
        }
        [NSThread sleepForTimeInterval:5];
    }
}



- (void)update {
    [[DataManager sharedInstance] deleteAllDataInBackground];
    NSArray * array = [[DataManager sharedInstance] fetchDataInBackgroundAndNotifyMainThread];
    NSLog(@"array: %ld",array.count);
    while (true) {
        dispatch_async(dispatch_get_main_queue(), ^{
            self.txtLabel.tag += 1;
            self.txtLabel.text = [NSString stringWithFormat:@"Count: %ld",self.txtLabel.tag];
        });
        [NSThread sleepForTimeInterval:1];
    }
}

- (Person *)createPersonWithName:(NSString *)name {
    Person *person = [[DataManager sharedInstance] getANewDataInBackground];
    person.name = name;
    
    NSMutableDictionary * testCase = [NSMutableDictionary dictionaryWithCapacity:5];
    
    NSMutableArray * filePaths = [NSMutableArray arrayWithCapacity:5];
    [filePaths addObject:@"1"];
    [filePaths addObject:@"2"];
    [filePaths addObject:@"3"];
    [filePaths addObject:@"4"];
    [testCase setValue:filePaths forKey:@"filePaths"];
    [testCase setValue:@"1" forKey:@"compressionType"];
    
    NSMutableArray * cars = [NSMutableArray arrayWithCapacity:5];
    [cars addObject:@"car1"];
    [cars addObject:@"car2"];
    [cars addObject:@"car3"];
    
    person.infos = testCase;
    person.cars = cars;
    return person;
}



@end
