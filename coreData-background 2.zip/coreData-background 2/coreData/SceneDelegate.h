//
//  SceneDelegate.h
//  coreData
//
//  Created by Lucas on 12/28/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

