//
//  DataManager.h
//  coreData
//
//  Created by Lucas on 1/12/24.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "Person+CoreDataProperties.h"

NS_ASSUME_NONNULL_BEGIN

@interface DataManager : NSObject




+ (instancetype)sharedInstance;
-(Person*)getANewDataInBackground;
-(void)performCoreDataOperation;
- (NSArray*)fetchDataInBackgroundAndNotifyMainThread;
- (void)saveTheData;
- (void)deleteAllDataInBackground;
@end

NS_ASSUME_NONNULL_END
