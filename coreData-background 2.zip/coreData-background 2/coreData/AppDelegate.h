//
//  AppDelegate.h
//  coreData
//
//  Created by Lucas on 12/28/23.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

