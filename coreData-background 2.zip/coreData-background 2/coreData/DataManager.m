#import "DataManager.h"
#import <CoreData/CoreData.h>

@interface DataManager ()

@property (nonatomic, strong) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, strong) NSManagedObjectContext *backgroundManagedObjectContext;
@property (nonatomic, strong) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, strong) NSPersistentStoreCoordinator *persistentStoreCoordinator;

@end

@implementation DataManager

+ (instancetype)sharedInstance {
    static DataManager *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
        [sharedInstance setupCoreData];
    });
    return sharedInstance;
}

- (void)setupCoreData {
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"Model" withExtension:@"momd"];
    self.managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    
    NSPersistentStoreCoordinator *coordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:self.managedObjectModel];
    self.managedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    [self.managedObjectContext setPersistentStoreCoordinator:coordinator];
    
    self.backgroundManagedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    [self.backgroundManagedObjectContext setParentContext:self.managedObjectContext];
    
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"ModelTest.sqlite"];
    
    NSError *error = nil;
    NSDictionary *options = @{NSMigratePersistentStoresAutomaticallyOption: @YES,
                              NSInferMappingModelAutomaticallyOption: @YES};
    
    if (![coordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:options error:&error]) {
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
}

- (NSURL *)applicationDocumentsDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

-(Person*)getANewDataInBackground {
    return [NSEntityDescription insertNewObjectForEntityForName:@"Person" inManagedObjectContext:self.backgroundManagedObjectContext];
}

- (void)insertDataInBackground {
    // Create a new managed object without assigning it to a variable
    ;
    
    NSError *error = nil;
    if (![self.backgroundManagedObjectContext save:&error]) {
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
    }
    
    [self.managedObjectContext performBlock:^{
        NSError *parentError = nil;
        if (![self.managedObjectContext save:&parentError]) {
            NSLog(@"Unresolved parent error %@, %@", parentError, [parentError userInfo]);
        }
    }];
}


- (void)performCoreDataOperation {
    NSManagedObjectContext *currentContext = [self currentContext];
    
    [currentContext performBlock:^{
        // 在 performBlock 中执行与上下文相关的操作
        // 这确保了在正确的队列上执行 Core Data 操作，并提供了线程安全性
        
        NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"Person"];
        // 设置操作条件
        // NSPredicate *predicate = [NSPredicate predicateWithFormat:@"yourAttribute == %@", yourValue];
        // [fetchRequest setPredicate:predicate];
        
        NSError *error = nil;
        NSArray *results = [currentContext executeFetchRequest:fetchRequest error:&error];
        // 处理获取到的数据或执行其他操作
        
        // 保存更改
        if ([currentContext hasChanges] && ![currentContext save:&error]) {
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        } else {
            // 切回主线程保存主上下文
            if ([currentContext isEqual:self.backgroundManagedObjectContext]) {
                [self.managedObjectContext performBlock:^{
                    NSError *parentError = nil;
                    if (![self.managedObjectContext save:&parentError]) {
                        NSLog(@"Unresolved parent error %@, %@", parentError, [parentError userInfo]);
                    }
                }];
            }
        }
        
    }];
}

- (void)saveTheData {
    NSManagedObjectContext *currentContext = [self currentContext];
    [currentContext performBlock:^{
        NSError *error = nil;

        if ([currentContext hasChanges] && ![currentContext save:&error]) {
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        } else {
            // 切回主线程保存主上下文
            if ([currentContext isEqual:self.backgroundManagedObjectContext]) {
                [self.managedObjectContext performBlock:^{
                    NSError *parentError = nil;
                    if (![self.managedObjectContext save:&parentError]) {
                        NSLog(@"Unresolved parent error %@, %@", parentError, [parentError userInfo]);
                    }
                }];
            }
        }
        
    }];
}
- (NSManagedObjectContext *)currentContext {
    if ([NSThread isMainThread]) {
        return self.managedObjectContext;
    } else {
        return self.backgroundManagedObjectContext;
    }
}


- (void)updateDataInBackground {
    NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"Person"];
    // 设置更新条件
    // NSPredicate *predicate = [NSPredicate predicateWithFormat:@"yourAttribute == %@", yourValue];
    // [fetchRequest setPredicate:predicate];
    
    NSError *error = nil;
    NSArray *results = [self.backgroundManagedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (results && results.count > 0) {
        // 不再使用 objectToUpdate 变量，直接在后台上下文中更新数据
        // [results.firstObject setValue:newValue forKey:@"yourAttribute"];
        
        if (![self.backgroundManagedObjectContext save:&error]) {
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        }
        
        [self.managedObjectContext performBlock:^{
            NSError *parentError = nil;
            if (![self.managedObjectContext save:&parentError]) {
                NSLog(@"Unresolved parent error %@, %@", parentError, [parentError userInfo]);
            }
        }];
    }
}


- (void)deleteDataInBackground {
    NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"Person"];
    // 设置删除条件
    // NSPredicate *predicate = [NSPredicate predicateWithFormat:@"yourAttribute == %@", yourValue];
    // [fetchRequest setPredicate:predicate];
    
    NSError *error = nil;
    NSArray *results = [self.backgroundManagedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (results && results.count > 0) {
        // 删除数据
        [self.backgroundManagedObjectContext deleteObject:results.firstObject];
        [self.backgroundManagedObjectContext deletedObjects];
        if (![self.backgroundManagedObjectContext save:&error]) {
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        }
        
        [self.managedObjectContext performBlock:^{
            NSError *parentError = nil;
            if (![self.managedObjectContext save:&parentError]) {
                NSLog(@"Unresolved parent error %@, %@", parentError, [parentError userInfo]);
            }
        }];
    }
}

- (void)deleteAllDataInBackground {
    NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"Person"];
    // 设置删除条件
    // NSPredicate *predicate = [NSPredicate predicateWithFormat:@"yourAttribute == %@", yourValue];
    // [fetchRequest setPredicate:predicate];

    NSError *error = nil;
    NSArray *allObjects = [self.backgroundManagedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (allObjects && allObjects.count > 0) {
        // 批量删除所有数据
        for (NSManagedObject *objectToDelete in allObjects) {
            [self.backgroundManagedObjectContext deleteObject:objectToDelete];
        }

        if (![self.backgroundManagedObjectContext save:&error]) {
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        }

        [self.managedObjectContext performBlock:^{
            NSError *parentError = nil;
            if (![self.managedObjectContext save:&parentError]) {
                NSLog(@"Unresolved parent error %@, %@", parentError, [parentError userInfo]);
            }
        }];
    }
}



- (NSArray*)fetchDataInBackgroundAndNotifyMainThread {
    NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"Person"];
    // 设置读取条件
    // NSPredicate *predicate = [NSPredicate predicateWithFormat:@"yourAttribute == %@", yourValue];
    // [fetchRequest setPredicate:predicate];
    
    NSError *error = nil;
    NSArray *results = [self.backgroundManagedObjectContext executeFetchRequest:fetchRequest error:&error];
    return results;
}

@end
