//
//  Person+CoreDataClass.m
//  coreData
//
//  Created by Lucas on 12/28/23.
//
//

#import "Person+CoreDataClass.h"

@implementation Person

@end
