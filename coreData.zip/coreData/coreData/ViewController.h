//
//  ViewController.h
//  coreData
//
//  Created by Lucas on 12/28/23.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

