#import "ViewController.h"
#import "AppDelegate.h" // Import the app delegate to access the managed object context
#import "Person+CoreDataProperties.h"

@interface ViewController ()
@property (nonatomic, strong) NSManagedObjectContext *managedObjectContext;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Set up the managed object context
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    self.managedObjectContext = appDelegate.persistentContainer.viewContext;

    NSString *targetName = @"John";
    Person *foundPerson = [self fetchPersonByName:targetName];
    
    if (foundPerson) {
        NSLog(@"foundPerson Person: %@, infos:%@, cars:%@", foundPerson.name, foundPerson.infos,foundPerson.cars);
    } else {
        Person *person = [self createPersonWithName:targetName];
        [self savePerson:person];

        NSLog(@"Person created with name %@", targetName);
    }

    // Create and save a Person

    // Fetch and print all Persons
    NSArray<Person *> *persons = [self fetchPersons];
    for (Person *person in persons) {
//        NSLog(@"Person: %@, infos:%@, cars:%@", person.name, person.infos,person.cars);
    }
}

- (Person *)createPersonWithName:(NSString *)name {
    Person *person = [NSEntityDescription insertNewObjectForEntityForName:@"Person" inManagedObjectContext:self.managedObjectContext];
    person.name = name;
    
    NSMutableDictionary * testCase = [NSMutableDictionary dictionaryWithCapacity:5];
    
    NSMutableArray * filePaths = [NSMutableArray arrayWithCapacity:5];
    [filePaths addObject:@"1"];
    [filePaths addObject:@"2"];
    [filePaths addObject:@"3"];
    [filePaths addObject:@"4"];
    [testCase setValue:filePaths forKey:@"filePaths"];
    [testCase setValue:@"1" forKey:@"compressionType"];
    
    NSMutableArray * cars = [NSMutableArray arrayWithCapacity:5];
    [cars addObject:@"car1"];
    [cars addObject:@"car2"];
    [cars addObject:@"car3"];
    
    person.infos = testCase;
    person.cars = cars;
    return person;
}

- (void)savePerson:(Person *)person {
    NSError *error = nil;
    if (![self.managedObjectContext save:&error]) {
        NSLog(@"Error saving person: %@", [error localizedDescription]);
    }
}

- (NSArray<Person *> *)fetchPersons {
    NSFetchRequest<Person *> *fetchRequest = [Person fetchRequest];

    NSError *error = nil;
    NSArray<Person *> *persons = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];

    if (error) {
        NSLog(@"Error fetching persons: %@", [error localizedDescription]);
        return @[];
    }

    return persons;
}

- (Person *)fetchPersonByName:(NSString *)name {
    NSFetchRequest<Person *> *fetchRequest = [Person fetchRequest];
    fetchRequest.predicate = [NSPredicate predicateWithFormat:@"name == %@", name];

    NSError *error = nil;
    NSArray<Person *> *persons = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];

    if (error) {
        NSLog(@"Error fetching person: %@", [error localizedDescription]);
        return nil;
    }

    return persons.firstObject;
}

@end
