//
//  Person+CoreDataProperties.m
//  coreData
//
//  Created by Lucas on 12/28/23.
//
//

#import "Person+CoreDataProperties.h"

@implementation Person (CoreDataProperties)

+ (NSFetchRequest<Person *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"Person"];
}

@dynamic name;
@dynamic infos;
@dynamic cars;

@end
